package student;
import java.util.Scanner;

public class Student {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Please Enter in Number");
        int student = scanner.nextInt();
        int creditHoursEarned = 0, pointsEarned = 0; 
        double gradePointAverage = 0.0;
        
        String idNumber = null;
        
        switch(student) {
            case 1:
                idNumber = "5433";
                creditHoursEarned = 3;
                pointsEarned = 12;
                
                break;
            
            case 2:
                idNumber = "3465";
                creditHoursEarned = 2;
                pointsEarned = 10;
                break;
            
            case 3:
                idNumber = "9700";
                creditHoursEarned = 8;
                pointsEarned = 18;
                break;
            
            case 4:
                idNumber = "1006";
                creditHoursEarned = 1;
                pointsEarned = 5;
                break;
            
            case 5:
                idNumber = "4587";
                creditHoursEarned = 5;
                pointsEarned = 16;
                break;
            
            case 6:
                idNumber = "0973";
                creditHoursEarned = 2;
                pointsEarned = 103;
                break;
            
            default:
                idNumber = "invalid number";
                break;
        }
        
        if (creditHoursEarned != 0 && pointsEarned != 0) {
            gradePointAverage = (double) pointsEarned / creditHoursEarned;
        }
        
        System.out.println("ID Number: " + idNumber);
        System.out.println("Credit Hours: " + creditHoursEarned);
        System.out.println("Points Earned: " + pointsEarned);
        System.out.println("Grade Point Average: " + gradePointAverage);
        
        scanner.close();
    }
}
