
package student;


public class ShowStudent {
    public static void main(String[] args) {
        // Instantiate Student object
        Student student = new Student();

        // Assign values to fields
        student.setIdNumber();
        student.setCreditHoursEarned();
        student.setPointsEarned();

        // Compute GPA
        double gradePointAverage = (double) student.getPointsEarned() / student.getCreditHoursEarned();

        // Display all values associated with the student
        System.out.println("Student ID: " + student.getIdNumber());
        System.out.println("Credit Hours Earned: " + student.getCreditHoursEarned());
        System.out.println("Points Earned: " + student.getPointsEarned());
        System.out.println("Grade Point Average: " + gradePointAverage);
    }
}
